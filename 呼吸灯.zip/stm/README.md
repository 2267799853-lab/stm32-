# STM32F103C8 定时器 LED 闪烁与 PWM 呼吸灯

基于 STM32F103C8T6、TIM2_CH1、TIM3 和标准外设库 V3.5.0 的 Keil µVision 工程。程序通过 LED 展示定时闪烁与 PWM 呼吸效果，不使用 OLED。

## 实验功能

- TIM3 每 10 ms 产生一次更新中断。
- 默认呼吸模式：TIM2_CH1 在 PA0 输出约 1 kHz PWM；占空比渐变理论周期约 2 s。
- 闪烁模式：每 100 次 TIM3 中断翻转 PA0，亮灭各约 1 s，完整周期约 2 s。
- 按 KEY1（PB1）或 KEY2（PB11）在两种模式间切换。

## 硬件连接

- PA0 → 330 Ω～1 kΩ 限流电阻 → LED 阳极；LED 阴极 → GND。
- KEY1 / KEY2 分别对应 PB1 / PB11，按下接地。
- DAPLink 使用 CMSIS-DAP / SWD，连接 SWDIO、SWCLK、GND，并按接口标识连接目标电压参考。
- 确认共地和供电；不要将 5 V 接到 3.3 V 引脚。

## 构建

使用 Keil µVision 5.24.2.0 与 ARM Compiler 5.06u5：

1. 打开 `Project/Project.uvprojx`。
2. 选择 `STM32F103C8` 与 ARM Compiler 5。
3. 执行 **Project → Build Target**。
4. 选择 **CMSIS-DAP Debugger**，不要选择 ULINK2/ME；SWD 初次连接可选较低时钟。
5. 在 Flash Download 中启用下载和校验后下载到开发板。

构建结果：0 错误、0 警告。链接空间：Code=2608、RO-data=268、RW-data=8、ZI-data=1632 字节。生成的 HEX 位于 `Project/Objects/TimerExternalClock.hex`，发布副本位于 `Firmware/TimerExternalClock.hex`。

## 实验报告

- [实验报告（DOCX）](Docs/实验报告.docx)
- [实验报告（Markdown）](Docs/实验报告.md)
- [实验报告（PDF）](Docs/实验报告.pdf)
- [博客草稿](Docs/博客草稿.md)

用户提供的 LED 实验 GIF：![LED 工作状态](Docs/images/led_experiment.gif)

## 说明

报告中的理论周期和 PWM 频率来自定时参数推导；动态图展示 LED 点亮现象，但不替代秒表或示波器对周期、载波频率和模式切换的独立测量。
