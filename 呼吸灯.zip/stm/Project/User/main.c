#include "stm32f10x.h"
#include "Delay.h"
#include "Key.h"
#include "Timer.h"

int main(void)
{
	uint8_t key;

	Key_Init();
	Timer_Init();

	while (1)
	{
		key = Key_GetNum();
		if (key != 0)
		{
			if (Timer_GetMode() == TIMER_MODE_BREATH)
			{
				Timer_SetMode(TIMER_MODE_BLINK);
			}
			else
			{
				Timer_SetMode(TIMER_MODE_BREATH);
			}
		}

		Delay_ms(20);
	}
}
