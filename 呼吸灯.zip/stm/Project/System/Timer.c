#include "stm32f10x.h"
#include "Timer.h"

#define LED_GPIO_PORT		GPIOA
#define LED_GPIO_PIN		GPIO_Pin_0
#define BLINK_TICKS			100
#define PWM_MAX_DUTY		100

static volatile Timer_Mode_t Timer_Mode = TIMER_MODE_BREATH;
static volatile uint16_t Timer_Tick = 0;
static volatile uint8_t Timer_Duty = 0;
static volatile int8_t Timer_Direction = 1;

static void Timer_ConfigureLedPin(Timer_Mode_t mode)
{
	GPIO_InitTypeDef GPIO_InitStructure;

	GPIO_InitStructure.GPIO_Pin = LED_GPIO_PIN;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = (mode == TIMER_MODE_BREATH) ?
	                               GPIO_Mode_AF_PP : GPIO_Mode_Out_PP;
	GPIO_Init(LED_GPIO_PORT, &GPIO_InitStructure);

	if (mode == TIMER_MODE_BLINK)
	{
		GPIO_ResetBits(LED_GPIO_PORT, LED_GPIO_PIN);
	}
}

void Timer_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
	TIM_OCInitTypeDef TIM_OCInitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2 | RCC_APB1Periph_TIM3, ENABLE);

	GPIO_InitStructure.GPIO_Pin = LED_GPIO_PIN;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_Init(LED_GPIO_PORT, &GPIO_InitStructure);

	/* TIM2_CH1 runs at 1 kHz with a 1 MHz timer counter clock. */
	TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInitStructure.TIM_Period = 1000 - 1;
	TIM_TimeBaseInitStructure.TIM_Prescaler = 72 - 1;
	TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;
	TIM_TimeBaseInit(TIM2, &TIM_TimeBaseInitStructure);

	TIM_OCStructInit(&TIM_OCInitStructure);
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
	TIM_OCInitStructure.TIM_Pulse = 0;
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
	TIM_OC1Init(TIM2, &TIM_OCInitStructure);
	TIM_OC1PreloadConfig(TIM2, TIM_OCPreload_Enable);
	TIM_ARRPreloadConfig(TIM2, ENABLE);
	TIM_Cmd(TIM2, ENABLE);

	/* TIM3 interrupts at 100 Hz: 10 ms per control tick. */
	TIM_TimeBaseInitStructure.TIM_Period = 100 - 1;
	TIM_TimeBaseInitStructure.TIM_Prescaler = 7200 - 1;
	TIM_TimeBaseInit(TIM3, &TIM_TimeBaseInitStructure);
	TIM_ClearFlag(TIM3, TIM_FLAG_Update);
	TIM_ITConfig(TIM3, TIM_IT_Update, ENABLE);

	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	NVIC_InitStructure.NVIC_IRQChannel = TIM3_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
	NVIC_Init(&NVIC_InitStructure);

	Timer_SetMode(TIMER_MODE_BREATH);
	TIM_Cmd(TIM3, ENABLE);
}

void Timer_SetMode(Timer_Mode_t mode)
{
	if (mode != TIMER_MODE_BLINK && mode != TIMER_MODE_BREATH)
	{
		return;
	}

	TIM_ITConfig(TIM3, TIM_IT_Update, DISABLE);
	Timer_Mode = mode;
	Timer_Tick = 0;

	if (mode == TIMER_MODE_BREATH)
	{
		Timer_Duty = 0;
		Timer_Direction = 1;
		TIM_SetCompare1(TIM2, 0);
		Timer_ConfigureLedPin(mode);
	}
	else
	{
		TIM_SetCompare1(TIM2, 0);
		Timer_ConfigureLedPin(mode);
	}

	TIM_ClearITPendingBit(TIM3, TIM_IT_Update);
	TIM_ITConfig(TIM3, TIM_IT_Update, ENABLE);
}

Timer_Mode_t Timer_GetMode(void)
{
	return Timer_Mode;
}

uint8_t Timer_GetDutyCycle(void)
{
	return Timer_Duty;
}

void TIM3_IRQHandler(void)
{
	if (TIM_GetITStatus(TIM3, TIM_IT_Update) == SET)
	{
		if (Timer_Mode == TIMER_MODE_BLINK)
		{
			Timer_Tick++;
			if (Timer_Tick >= BLINK_TICKS)
			{
				Timer_Tick = 0;
				if (GPIO_ReadOutputDataBit(LED_GPIO_PORT, LED_GPIO_PIN) == Bit_SET)
				{
					GPIO_ResetBits(LED_GPIO_PORT, LED_GPIO_PIN);
				}
				else
				{
					GPIO_SetBits(LED_GPIO_PORT, LED_GPIO_PIN);
				}
			}
		}
		else
		{
			if (Timer_Direction > 0)
			{
				if (Timer_Duty == PWM_MAX_DUTY)
				{
					Timer_Direction = -1;
					Timer_Duty--;
				}
				else
				{
					Timer_Duty++;
				}
			}
			else if (Timer_Duty == 0)
			{
				Timer_Direction = 1;
				Timer_Duty++;
			}
			else
			{
				Timer_Duty--;
			}

			TIM_SetCompare1(TIM2, (1000 * Timer_Duty) / 100);
		}

		TIM_ClearITPendingBit(TIM3, TIM_IT_Update);
	}
}
