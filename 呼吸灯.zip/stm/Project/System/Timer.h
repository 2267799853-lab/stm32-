#ifndef __TIMER_H
#define __TIMER_H

#include <stdint.h>

typedef enum
{
	TIMER_MODE_BLINK = 0,
	TIMER_MODE_BREATH = 1
} Timer_Mode_t;

void Timer_Init(void);
void Timer_SetMode(Timer_Mode_t mode);
Timer_Mode_t Timer_GetMode(void);
uint8_t Timer_GetDutyCycle(void);

#endif
