/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : USART1 115200 8N1 polling, interrupt and DMA exercises
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <string.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* Select 1=polling TX, 2=interrupt-controlled polling TX, 3=DMA TX, 4=register diagnostic, 5=simulated 8N1 trace. */
#define EX_TASK   1


/* Set to 0 to observe maximum continuous throughput. */
#define TX_INTERVAL_MS       500U

#define DMA_TEST_BAUD        115200U
/* USER CODE END PD */

#if EX_TASK == 5
UART_HandleTypeDef huart1;
DMA_HandleTypeDef hdma_usart1_tx;
volatile uint32_t sim_tx_level = 1U;

__asm void SimDelayBit(void)
{
  MOV R0, #16
SimDelayLoop
  SUBS R0, R0, #1
  BNE SimDelayLoop
  NOP
  NOP
  BX LR
}

static void SimSendByte(uint8_t value)
{
  uint32_t bit;


  sim_tx_level = 0U;
  SimDelayBit();
  for (bit = 0U; bit < 8U; bit++)
  {
    sim_tx_level = (uint32_t)((value >> bit) & 1U);
    SimDelayBit();
  }
  sim_tx_level = 1U;
  SimDelayBit();
}

int main(void)
{
  while (1)
  {
    SimSendByte((uint8_t)'h');
    SimDelayBit();
  }
}

void Error_Handler(void)
{
  while (1)
  {
  }
}
#else
/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
UART_HandleTypeDef huart1;

/* USER CODE BEGIN PV */
DMA_HandleTypeDef hdma_usart1_tx;

#if EX_TASK == 3 || EX_TASK == 4
static uint32_t next_tx_tick;
#endif
#if EX_TASK == 1 || EX_TASK == 2 || EX_TASK == 3
static volatile uint8_t stream_enabled = 1U;
#endif
#if EX_TASK == 3
static volatile uint8_t reply_pending = 0U;
#endif
static volatile uint8_t rx_error = 0U;
#if EX_TASK == 3
static volatile uint8_t dma_ready = 1U;
#endif
#if EX_TASK != 4
static uint8_t rx_byte;
#endif

#if EX_TASK == 1 || EX_TASK == 2 || EX_TASK == 3
static const uint8_t hello_msg[] = "hello windows!\r\n";
#endif
#if EX_TASK == 4
static const uint8_t diagnostic_msg[] = "USART1 POLLING TEST\r\n";
#endif
#if EX_TASK != 4
static const uint8_t ready_msg[] = "USART1 115200 8N1 ready\r\n";
#endif
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART1_UART_Init(void);
/* USER CODE BEGIN PFP */
static void MX_DMA_Init(void);
#if EX_TASK == 4
static void USART1_RegisterPollingInit(void);
static uint8_t USART1_RegisterSend(const uint8_t *data, uint16_t length);
#endif
#if EX_TASK == 3
static uint8_t ConsumeReply(void);
#endif
#if EX_TASK != 4
static void SendPolling(const uint8_t *data, uint16_t length);
#endif
#if EX_TASK == 3
static void SendDma(const uint8_t *data, uint16_t length);
#endif
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */
  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_USART1_UART_Init();
  /* USER CODE BEGIN 2 */
#if EX_TASK != 4
  HAL_NVIC_SetPriority(USART1_IRQn, 1, 0);
  HAL_NVIC_EnableIRQ(USART1_IRQn);
#endif

  if ((EX_TASK == 3U) && (DMA_TEST_BAUD != 115200U))
  {
    huart1.Init.BaudRate = DMA_TEST_BAUD;
    if (HAL_UART_Init(&huart1) != HAL_OK)
    {
      Error_Handler();
    }
  }

#if EX_TASK != 4
  if (HAL_UART_Receive_IT(&huart1, &rx_byte, 1U) != HAL_OK)
  {
    Error_Handler();
  }
  SendPolling(ready_msg, sizeof(ready_msg) - 1U);
#else
  HAL_NVIC_DisableIRQ(USART1_IRQn);
  USART1_RegisterPollingInit();
  next_tx_tick = HAL_GetTick() + 1000U;
#endif
#if EX_TASK == 3
  next_tx_tick = HAL_GetTick();
#endif
  /* USER CODE END 2 */

  while (1)
  {
    if (rx_error != 0U)
    {
      Error_Handler();
    }
#if EX_TASK == 4
    if ((USART1->SR & USART_SR_RXNE) != 0U)
    {
      uint8_t received = (uint8_t)USART1->DR;
      if (USART1_RegisterSend(&received, 1U) == 0U)
      {
        Error_Handler();
      }
    }
    if ((int32_t)(HAL_GetTick() - next_tx_tick) >= 0)
    {
      if (USART1_RegisterSend(diagnostic_msg, sizeof(diagnostic_msg) - 1U) == 0U)
      {
        Error_Handler();
      }
      next_tx_tick = HAL_GetTick() + 1000U;
    }

#elif EX_TASK == 1
    if (stream_enabled != 0U)
    {
      SendPolling(hello_msg, sizeof(hello_msg) - 1U);
      if (TX_INTERVAL_MS != 0U)
      {
        HAL_Delay(TX_INTERVAL_MS);
      }
    }
    else
    {
      HAL_Delay(1U);
    }

#elif EX_TASK == 2
    if (stream_enabled != 0U)
    {
      SendPolling(hello_msg, sizeof(hello_msg) - 1U);
      if (TX_INTERVAL_MS != 0U)
      {
        HAL_Delay(TX_INTERVAL_MS);
      }
    }
    else
    {
      HAL_Delay(1U);
    }

#elif EX_TASK == 3
    if (dma_ready != 0U)
    {
      if (ConsumeReply() != 0U)
      {
        SendDma(hello_msg, sizeof(hello_msg) - 1U);
      }
      else if ((stream_enabled != 0U) &&
               ((TX_INTERVAL_MS == 0U) ||
                ((int32_t)(HAL_GetTick() - next_tx_tick) >= 0)))
      {
        SendDma(hello_msg, sizeof(hello_msg) - 1U);
        next_tx_tick = HAL_GetTick() + TX_INTERVAL_MS;
      }
    }
    else
    {
      HAL_Delay(1U);
    }
#endif
  }
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI_DIV2;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL16;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_SYSCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
}

static void MX_DMA_Init(void)
{
  __HAL_RCC_DMA1_CLK_ENABLE();
  HAL_NVIC_SetPriority(DMA1_Channel4_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel4_IRQn);
}

/* USER CODE BEGIN 4 */
#if EX_TASK == 4
static void USART1_RegisterPollingInit(void)
{
  USART1->CR1 = 0U;
  USART1->CR2 = 0U;
  USART1->CR3 = 0U;
  USART1->BRR = (HAL_RCC_GetPCLK2Freq() + 57600U) / 115200U;
  USART1->CR1 = USART_CR1_UE | USART_CR1_TE | USART_CR1_RE;
}

static uint8_t USART1_RegisterSend(const uint8_t *data, uint16_t length)
{
  uint32_t started = HAL_GetTick();

  while (length != 0U)
  {
    if ((USART1->SR & USART_SR_TXE) != 0U)
    {
      USART1->DR = *data++;
      length--;
      started = HAL_GetTick();
    }
    else if ((uint32_t)(HAL_GetTick() - started) > 20U)
    {
      return 0U;
    }
  }

  while ((USART1->SR & USART_SR_TC) == 0U)
  {
    if ((uint32_t)(HAL_GetTick() - started) > 20U)
    {
      return 0U;
    }
  }
  return 1U;
}
#endif

#if EX_TASK == 3
static uint8_t ConsumeReply(void)
{
  uint8_t pending;
  uint32_t primask = __get_PRIMASK();
  __disable_irq();
  pending = reply_pending;
  reply_pending = 0U;
  if (primask == 0U)
  {
    __enable_irq();
  }
  return pending;
}
#endif

#if EX_TASK != 4
static void SendPolling(const uint8_t *data, uint16_t length)
{
  if (HAL_UART_Transmit(&huart1, (uint8_t *)data, length, 1000U) != HAL_OK)
  {
    rx_error = 1U;
  }
}
#endif

#if EX_TASK == 3
static void SendDma(const uint8_t *data, uint16_t length)
{
  if (HAL_UART_Transmit_DMA(&huart1, (uint8_t *)data, length) != HAL_OK)
  {
    rx_error = 1U;
  }
  else
  {
    dma_ready = 0U;
  }
}
#endif

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
#if EX_TASK != 4
  if (huart->Instance == USART1)
  {
#if EX_TASK == 1 || EX_TASK == 2 || EX_TASK == 3
    if (rx_byte == (uint8_t)'#')
    {
      stream_enabled = 0U;
#if EX_TASK == 3
      reply_pending = 1U;
#endif
    }
    else if (rx_byte == (uint8_t)'*')
    {
      stream_enabled = 1U;
    }
#endif
    if (HAL_UART_Receive_IT(&huart1, &rx_byte, 1U) != HAL_OK)
    {
      rx_error = 1U;
    }
  }
#else
  (void)huart;
#endif
}

void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{
#if EX_TASK == 3
  if (huart->Instance == USART1)
  {
    dma_ready = 1U;
  }
#else
  (void)huart;
#endif
}

void HAL_UART_ErrorCallback(UART_HandleTypeDef *huart)
{
  if (huart->Instance == USART1)
  {
    rx_error = 1U;
  }
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  __disable_irq();
  while (1)
  {
  }
}

#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
#endif
