# STM32 USART 串口实验

目标器件：STM32F103C8T6。工程采用 STM32CubeMX 6.15 配置、STM32 HAL、Keil MDK-ARM 5；串口为 USART1，默认 115200 bit/s、8 数据位、无校验、1 停止位（8N1）。

## 工程文件

- `USART.ioc`：CubeMX 配置，PA9/PA10 为 USART1，USART1_TX 使用 DMA1_Channel4。
- `MDK-ARM\USART.uvprojx`：Keil 工程文件。
- `MDK-ARM\USART.uvoptx`：DAPLink/CMSIS-DAP 调试器与下载器选择。
- `Core\Src\main.c`：三种正式实验模式和一个寄存器轮询诊断模式。当前 `EX_TASK=1` 用于任务一；可选 `2`、`3` 运行其他实验，或选 `4` 检查串口：
  - `1`：轮询发送 `hello windows!`，每帧间隔 500 ms；接收中断通过 `#` 暂停、`*` 恢复。
  - `2`：接收中断解析 `#`/`*`，分别暂停/恢复轮询发送；发送间隔由 `TX_INTERVAL_MS` 设置。
  - `3`：接收中断控制 DMA 连续发送；`#` 暂停并回发一次，`*` 恢复。
- `4`：不启用 USART 接收中断或 DMA；启动 1 秒后用 USART1 寄存器轮询从 PA9 发送 ASCII `USART1 POLLING TEST`，并把 PA10 收到的每个字符原样回显。
- `5`：Keil Simulator 专用软件 8N1 位序模型，将字符 `h` 的逻辑电平写入 `sim_tx_level` 供 Logic Analyzer 观察。它不驱动 USART 外设或 PA9，延时也未校准为目标波特率；仅用于报告中的逻辑位序截图，不可作为任务一/二实板验证固件。
- `实验报告.md` / `实验报告.html` / `实验报告.docx` / `实验报告.pdf`：实验过程、任务一/二验证记录、任务三 Keil 软件波形模型截图及波特率计算；Word 文档内嵌图片，报告说明软件模型不是实板测量。
- `MDK-ARM\USART\USART.hex`：当前任务一（模式 1）的 Keil 编译输出；Rebuild 后 HEX 会随 `EX_TASK` 设置更新。

## 编译和下载

1. 用 CubeMX 打开 `USART.ioc` 查看目标芯片、时钟、USART1 和 DMA 设置。
2. 用 Keil 打开 `MDK-ARM\USART.uvprojx`。如果工程要求安装器件包，选择 STM32F103C8 / STM32F103xB，并确认使用 ARM Compiler 5。
3. 工程已按 DAPLink 配好 CMSIS-DAP 调试器及 STM32F1 Flash 下载算法，设置保存在 `MDK-ARM\USART.uvoptx`。如果 Keil 仍提示找不到调试器，在 `Options for Target → Debug → Use` 选择 `CMSIS-DAP Debugger`，点 `Settings` 后选 SW/SWD 接口；`Options for Target → Utilities` 也选 CMSIS-DAP。将 DAPLink 通过 USB 接入后再点 Debug/Download。
4. 当前 `EX_TASK=1` 用于任务一。若需排查串口空白，将 `EX_TASK` 临时改为 `4`，Rebuild / Download 后复位；应每秒看到 ASCII `USART1 POLLING TEST`，发送 `A` 应看到回显的 `A`。诊断完成后改回 `EX_TASK=1` 并重新 Rebuild / Download。
5. 板子按 PA9/PA10 接好后下载并复位。
6. `TX_INTERVAL_MS` 默认 500 ms，便于观察文本。设为 `0` 可测试无额外间隔时的连续发送；DMA 波特率由 `DMA_TEST_BAUD` 设置，第一次测试建议保持 115200。

## USB-TTL 接线和串口助手

使用 3.3 V TTL 电平的 USB-TTL 模块，不要把传统 RS-232 的正负电压直接接到 STM32 引脚。

| USB-TTL 模块 | STM32F103C8T6 |
| --- | --- |
| TXD | PA10 / USART1_RX |
| RXD | PA9 / USART1_TX |
| GND | GND |

双方必须共地。不要把 USB-TTL 的 5 V 电源脚接到 MCU 信号脚；开发板建议独立供电，除非已确认模块与板子的电源设计兼容。串口助手选择设备管理器中对应 DAPLink/USB Serial Device 的 COM 口、115200、8 数据位、无校验、1 停止位、无流控。当前电脑中 DAPLink 显示为 COM7；COM 号可能变化，插拔后应重新确认。观察文本时选择 ASCII/文本显示；发送控制字符时关闭自动追加回车/换行。

## 实验操作

- 模式 1：每 500 ms 轮询发送一次 `hello windows!`；发送 `#` 后停止，发送 `*` 后恢复。
- 模式 2：接收中断逐字节解析控制命令。发送 `#` 后连续输出停止，发送 `*` 后恢复；串口助手发送命令时请关闭自动附加换行。
- 模式 3：DMA 每次完成一帧后由主循环发起下一次；同样用 `#` 暂停、`*` 恢复。切换模式后必须重新 Rebuild 和 Download。

## 使用注意

- 若连续发送时窗口显示卡顿，不等于 MCU 串口一定丢字节；串口助手的绘制、USB 转串口缓存和 PC 调度都可能影响显示。可降低速率或增大 `TX_INTERVAL_MS` 对比。
- 串口接收和 DMA 发送若返回 HAL 错误，程序进入 `Error_Handler`；复位后重新测试并检查串口参数。
- `实验报告.md` 中标有“实测”的空项必须接上你的开发板和串口模块后填写。Keil 编译成功不代表已完成物理串口验证。
