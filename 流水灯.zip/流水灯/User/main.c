=- 
#include "stm32f10x.h"
#include "Delay.h"

#define LED1_ON()   (GPIOA->BSRR = (1 << 0))  
#define LED1_OFF()  (GPIOA->BRR  = (1 << 0))   
#define LED2_ON()   (GPIOA->BSRR = (1 << 5))   
#define LED2_OFF()  (GPIOA->BRR  = (1 << 5))   
#define LED3_ON()   (GPIOC->BRR  = (1 << 13))  
#define LED3_OFF()  (GPIOC->BSRR = (1 << 13))  
#define LED4_ON()   (GPIOB->BSRR = (1 << 1))   
#define LED4_OFF()  (GPIOB->BRR  = (1 << 1))  

int main(void)
{
    RCC->APB2ENR |= (1 << 2);  
    RCC->APB2ENR |= (1 << 3);
    RCC->APB2ENR |= (1 << 4); 

    GPIOA->CRL &= ~(0xF << (0 * 4));
    GPIOA->CRL |=  (0x3 << (0 * 4));

    GPIOA->CRL &= ~(0xF << (5 * 4));
    GPIOA->CRL |=  (0x3 << (5-0 * 4));

    GPIOB->CRL &= ~(0xF << (1 * 4));
    GPIOB->CRL |=  (0x3 << (1 * 4));

    GPIOC->CRH &= ~(0xF << ((13 - 8) * 4));
    GPIOC->CRH |=  (0x3 << ((13 - 8) * 4));

    LED1_OFF();
    LED2_OFF();
    LED3_OFF();
    LED4_OFF();

    while(1)
    {
        LED1_ON();
        Delay_ms(1000);
        LED1_OFF();

        LED2_ON();
        Delay_ms(1000);
        LED2_OFF();

        LED3_ON();
        Delay_ms(1000);
        LED3_OFF();

        LED4_ON();
        Delay_ms(1000);
        LED4_OFF();
    }
}
